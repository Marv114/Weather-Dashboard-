// script.js

const apiKey = "314e4e5ccee8d40f0b72e62b5f7d890d"; // Replace with your OpenWeatherMap API key
const searchBtn = document.getElementById("search-btn");
const cityInput = document.getElementById("city-input");
const weatherInfo = document.getElementById("weather-info");
const errorMessage = document.getElementById("error-message");

searchBtn.addEventListener("click", () => {
    const cityName = cityInput.value.trim();
    if (cityName === "") {
        showError("Please enter a city name.");
        return;
    }

    fetchWeather(cityName);
});

async function fetchWeather(city) {
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error("City not found.");
        }

        const data = await response.json();
        displayWeather(data);
    } catch (error) {
        showError(error.message);
    }
}

function displayWeather(data) {
    // Hide error message
    errorMessage.classList.add("hidden");

    // Display weather information
    weatherInfo.classList.remove("hidden");
    document.getElementById("city-name").textContent = `${data.name}, ${data.sys.country}`;
    document.getElementById("temperature").textContent = `Temperature: ${data.main.temp}°C`;
    document.getElementById("description").textContent = `Description: ${data.weather[0].description}`;
    document.getElementById("humidity").textContent = `Humidity: ${data.main.humidity}%`;
    document.getElementById("wind-speed").textContent = `Wind Speed: ${data.wind.speed} m/s`;
}

function showError(message) {
    weatherInfo.classList.add("hidden");
    errorMessage.textContent = message;
    errorMessage.classList.remove("hidden");
}
